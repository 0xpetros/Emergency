package com.example.emergency;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class ContactActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> divisions;
    Toolbar toolbar;
    private Toolbar supportActionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        //Setting Custom Toolbar
        toolbar = findViewById(R.id.activity_contact_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Emergency Contacts");

        //Adding back button on action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        listView = findViewById(R.id.contactListView);

        //Get division names
        divisions = new ArrayList<>(Arrays.asList(getResources().getStringArray(String.valueOf(R.array.divison_list))));

        CustomAdapter customAdapter = new CustomAdapter(ContactActivity.this, divisions, R.drawable.bangladesh);
        listView.setAdapter(customAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ContactActivity.this, ListContactsActivity.class);
                intent.putExtra("division", divisions.get(position));
                startActivity(intent);
            }
        });
    }

    private ResourceBundle getResources() {
        return null;
    }

    public void setSupportActionBar(Toolbar supportActionBar) {
        this.supportActionBar = supportActionBar;
    }

    public Toolbar getSupportActionBar() {
        return supportActionBar;
    }
}
